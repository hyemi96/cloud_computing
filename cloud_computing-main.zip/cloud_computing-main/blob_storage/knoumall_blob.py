import os
from azure.storage.blob import BlobServiceClient

try :
    print("한국방송통신대학교 4학년 2학기 클라우드 컴퓨팅")
    # 여기에 코드를 작성한다.

except Exception as ex:
    print('Exception:')
    print(ex)
