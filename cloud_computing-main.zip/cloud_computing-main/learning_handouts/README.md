Learning Handouts
